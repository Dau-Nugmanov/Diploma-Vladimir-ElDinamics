//---------------------------------------------------------------------------
#ifndef LinkUnitH
#define LinkUnitH
//---------------------------------------------------------------------------
extern void __fastcall PopupToolbarMenu();
extern void __fastcall RxWebSite();
#endif

